package com.example.mylist1;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Set;

import org.apache.http.util.ByteArrayBuffer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.util.Log;


public class ActivitiesDS extends AbstractDS {
	
	private ArrayList<ActivityModel> m_data = new ArrayList<ActivityModel>();
	
	private Drawable m_genericIcon = null;
	private volatile boolean m_is_loading = false;
	private SharedPreferences m_system_settings = null;
	
	public ActivitiesDS(Context context) {
		m_genericIcon = context.getResources().getDrawable(R.drawable.pray);
	}
	
	// UI thread only
	public void load(Context context) {
		
		// find when the activities were most recently loaded
		m_system_settings = context.getSharedPreferences(TheLifeApplication.SYSTEM_PREFERENCES_FILE, Context.MODE_PRIVATE);
		long last_activity_load = m_system_settings.getLong("last_activity_load", 0);
		System.out.println("the last activity load was " + last_activity_load);
		
		// if the activities were not loaded recently
		if (System.currentTimeMillis() - last_activity_load > TheLifeApplication.RELOAD_ACTIVITIES_DELTA) {
				
			// if the activities are not already being loaded
			if (!m_is_loading) {  // okay to test, since this is only in the UI (main) thread
				try {
					m_is_loading = true;
					System.out.println("WILL NOW RUN LOAD ACTIVITIES");
					new readJSON().execute(new URL("http://thelife.ballistiq.com/activities.json"));
				} catch (MalformedURLException e) {
					e.printStackTrace();		
				} finally {
					m_is_loading = false;
				}
			}
			
		}
	}
	
	private class readJSON extends AsyncTask<URL, Void, JSONArray> {
		
		// background thread		
		@Override
		protected JSONArray doInBackground(URL... urls) {
			JSONArray objects = null;
				
			HttpURLConnection activitiesConnection = null;
			try {
				Thread.sleep(5000); // TODO: testing
				
				System.out.println("AM NOW BE RUNNING READJSON with" + urls[0]);				
				URL activitiesEP = urls[0];
				activitiesConnection = (HttpURLConnection)activitiesEP.openConnection();
				activitiesConnection.setConnectTimeout(TheLifeApplication.HTTP_CONNECTION_TIMEOUT);
				activitiesConnection.setConnectTimeout(TheLifeApplication.HTTP_READ_TIMEOUT);
				
				Log.e("JSON", "GOT THE RESPONSE CODE" + activitiesConnection.getResponseCode());

				// TODO TIME OUT?
				if (activitiesConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
					
					InputStream activitiesInput = activitiesConnection.getInputStream();
				
					byte buffer[] = new byte[1024];
					ByteArrayBuffer json_string = new ByteArrayBuffer(1024);
					
					int numBytesRead = activitiesInput.read(buffer);
					while (numBytesRead != -1) {
						json_string.append(buffer, 0, numBytesRead);
						numBytesRead = activitiesInput.read(buffer);
					}
					objects = new JSONArray(new String(json_string.toByteArray()));
					
					System.out.println("THE JSON OBJECT IS NOW " + objects.getJSONObject(0));
				}
			} catch (InterruptedException e) {
				;			
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();				
			} catch (JSONException e) {
				e.printStackTrace();
			} finally {
				if (activitiesConnection != null) {
					activitiesConnection.disconnect();
				}
				
			}	
			
			return objects;
		}
		
		// UI thread		
		@Override
		protected void onPostExecute(JSONArray objects) {
			
			System.out.println("HERE IN ON POST EXECUTE");
			ArrayList<ActivityModel> m_data2 = new ArrayList<ActivityModel>();
						
			try {
				for (int i = 0; i < objects.length(); i++) {
					JSONObject object = objects.getJSONObject(i);
					Log.e("JSON", "GOT ANOTHER JSON OBJECT");
					System.out.println("TITLE IS " + object.optString("title", ""));		

					// set up the thresholds
					JSONArray jsThresholds = object.optJSONArray("thresholds");
					Set<FriendModel.Threshold> thresholds = EnumSet.noneOf(FriendModel.Threshold.class);
					for (int j = 0; j < jsThresholds.length(); j++) {
						int intThreshold = jsThresholds.getInt(j);
						thresholds.add(FriendModel.thresholdValues[intThreshold]);
					}
					
					// create the activity
					ActivityModel activity = new ActivityModel(
						object.getInt("activity_id"),
						object.getString("title"),
						object.getString("summary"),
						object.getString("description"),
						object.getString("category"),
						m_genericIcon,
						thresholds
					);
					
					m_data2.add(activity);
				}
				
				m_data = m_data2;
				notifyDataStoreListeners(m_data);
				
				// release lock
				m_is_loading = false;
				
				// remember the timestamp of this successful load
				SharedPreferences.Editor system_settings_editor = m_system_settings.edit();
				system_settings_editor.putLong("last_activity_load", System.currentTimeMillis());
				system_settings_editor.commit();
				
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		
	}	
	
	public Collection<ActivityModel> findAll() {
		return m_data;
	}

	public ActivityModel findById(int activity_id) {
		
		for (ActivityModel m:m_data) {
			if (m.activity_id == activity_id) {
				return m;
			}		
		}
		
		return null;
	}
	
	public Collection<ActivityModel> findByThreshold(FriendModel.Threshold threshold) {
		ArrayList<ActivityModel> activities = new ArrayList<ActivityModel>();
		
		for (ActivityModel m:m_data) {
			if (m.is_applicable(threshold)) {
				activities.add(m);
			}		
		}
		
		return activities;
	}

}
