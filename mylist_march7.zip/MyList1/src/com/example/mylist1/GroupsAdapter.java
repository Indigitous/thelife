package com.example.mylist1;

import java.util.Collection;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class GroupsAdapter extends ArrayAdapter<GroupModel> {
	
	public GroupsAdapter(Context context, int mode, TheLifeApplication app) {
		super(context, mode);
		
		// get all the Groups for the current user
		Collection<GroupModel> Groups = app.getGroupsDS().findAll();
		for (GroupModel f:Groups) {
			add(f);
		}
	}
	
	// see ApiDemos List14.java for other (maybe better?) ways for this
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		View groupView = convertView;
		if (groupView == null) {
			LayoutInflater inflator = LayoutInflater.from(getContext());
			groupView = inflator.inflate(R.layout.group_cell, null);
		}
		
		GroupModel group = getItem(position);
			
		// TODO this could be done with a simple string array adapter, instead of this custom class
		TextView nameView = (TextView)groupView.findViewById(R.id.group_name);
		nameView.setTextSize(20.0f);
		nameView.setText(group.name);
		
		groupView.setTag(group);		
							
		return groupView;
	}

}
