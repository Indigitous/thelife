package com.example.mylist1;

import java.util.Set;

import android.graphics.drawable.Drawable;


// POJO - plain old java object
// TODO - activities to move a friend to a different (lower or higher) threshold
public class ActivityModel {
	
	public int    					activity_id;
	public String 					title;
	public String					summary;
	public String 					description;
	public String					category;
	public Drawable                 image;  // TODO is this an image id, image or what?
										    // TODO do we need a bigger image and a thumbnail?	
	public Set<FriendModel.Threshold> thresholds;
	
	public ActivityModel(int activity_id, String title, String summary, String description, String category, Drawable image, Set<FriendModel.Threshold> thresholds) {
		this.activity_id = activity_id;
		this.title = title;
		this.summary = summary;
		this.description = description;
		this.category = category;
		this.image = image;
		this.thresholds = thresholds;
	}
	
	public boolean is_applicable(FriendModel.Threshold threshold) {
		return thresholds.contains(threshold);
	}
	
	@Override
	public String toString() {
		return activity_id + ", " + title + ", " + summary + ", " + description + ", " + category + ", " + thresholds;
	}

}
