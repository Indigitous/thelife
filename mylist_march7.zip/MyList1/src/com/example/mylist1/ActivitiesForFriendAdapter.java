package com.example.mylist1;

import java.util.AbstractList;
import java.util.Collection;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ActivitiesForFriendAdapter extends ArrayAdapter<ActivityModel> implements DataStoreListener {
	
	private FriendModel m_friend;
	
	public ActivitiesForFriendAdapter(Context context, int mode, TheLifeApplication app, FriendModel friend) {
		super(context, mode);
		
		m_friend = friend;
		
		// get all the Activities for the current user		
		Collection<ActivityModel> Activities = app.getActivitiesDS().findByThreshold(m_friend.threshold);
		for (ActivityModel m:Activities) {
			add(m);
		}
	}
	
	// see ApiDemos List14.java for other (maybe better?) ways for this
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		View activityView = convertView;
		if (activityView == null) {
			LayoutInflater inflator = LayoutInflater.from(getContext());
			activityView = inflator.inflate(R.layout.activity_cell, null);
		}
		
		ActivityModel activity = getItem(position);
		
		ImageView imageView = (ImageView)activityView.findViewById(R.id.activity_image);
		imageView.setImageDrawable(activity.image);
		
		TextView textView = (TextView)activityView.findViewById(R.id.activity_title);
		textView.setText(Utilities.fill_template_string(m_friend, activity.title));
		
		activityView.setTag(activity);		
					
		return activityView;
	}

	@Override
	public void notifyDataChanged(AbstractList<?> newData) {
		clear();
		
		AbstractList<ActivityModel> newActivities = (AbstractList<ActivityModel>)newData;
		for (ActivityModel m:newActivities) {
			add(m);
		}
		notifyDataSetChanged();
	}

}
