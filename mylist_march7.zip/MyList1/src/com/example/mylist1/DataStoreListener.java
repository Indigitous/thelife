package com.example.mylist1;

import java.util.AbstractList;

public interface DataStoreListener {
	
	public void notifyDataChanged(AbstractList<?> newData);

}
